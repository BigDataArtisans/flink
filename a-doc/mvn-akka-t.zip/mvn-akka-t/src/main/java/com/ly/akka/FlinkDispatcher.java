package com.ly.akka;

import akka.actor.AbstractActor;
import akka.event.Logging;
import akka.event.LoggingAdapter;
import akka.japi.pf.ReceiveBuilder;

public class FlinkDispatcher extends AbstractActor {
    protected final LoggingAdapter log =
            Logging.getLogger(context().system(), this);

    private FlinkDispatcher() {
        receive(ReceiveBuilder
                .match(String.class, message -> {

                    log.info("收到信息 " + message);
                    Thread.sleep(30 * 1000);
                    log.info("处理完成 " + message);

                })
                .matchAny(o -> log.info("received unknown message: {}", o))
                .build());
    }
}