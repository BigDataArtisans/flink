package com.ly.akka;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Props;

public class Test {

    public static void main(String[] args) throws Exception {

        ActorSystem system = ActorSystem.create();
        ActorRef actorRef = system.actorOf(Props.create(FlinkDispatcher.class));

        new Thread(new Runnable() {
            @Override
            public void run() {
                actorRef.tell("savepoint message", ActorRef.noSender());
            }
        }).start();


        Thread.sleep(2000);

        new Thread(new Runnable() {
            @Override
            public void run() {
                actorRef.tell("heartbeat message", ActorRef.noSender());
            }
        }).start();

        Thread.sleep(300000);

    }


}
